
package javaqueue;


public class JavaQueue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FormFila form = new FormFila();
        form.setVisible(true);
    }
    
}
